package com.niit.firstdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.niit.firstdemo.model.Course;
import com.niit.firstdemo.service.CourseService;

@RestController
@RequestMapping("/")
@CrossOrigin(origins = "http://localhost:4200")
public class CourseController {
	@Autowired
	private CourseService courseService;
	
	@PostMapping
	public ResponseEntity<Void> addCourse(@RequestBody Course course)
	{
		System.out.println(course);
		System.out.println(courseService.addCourse(course));
		return new ResponseEntity<>(HttpStatus.CREATED);
	}
	
	@GetMapping
	public ResponseEntity<List<Course>> getAllCourses()
	{
		return new ResponseEntity<List<Course>>(courseService.getAllCourses(), HttpStatus.OK);
	}
	
	@DeleteMapping("id/{courseId}")
	public ResponseEntity<Void> deleteCourse(@PathVariable("courseId") int courseId)
	{
		Course course=new Course();
		course.setCourse_id(courseId);
		courseService.deleteCourse(course);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
	
	
	  @GetMapping("id/{courseId}")
	  public ResponseEntity<Course> searchCourse(@PathVariable("courseId")int courseId) {
		  return new ResponseEntity<Course>(courseService.searchCourseById(courseId),HttpStatus.OK);
	  
	  }
	 
	@PutMapping
	public ResponseEntity<Void> updateCourse(@RequestBody Course course)
	{
		courseService.updateCourse(course);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	

}
