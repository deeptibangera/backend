package com.niit.firstdemo;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringJUnitConfig;
import org.springframework.test.context.junit4.SpringRunner;

import com.niit.firstdemo.config.DBConfig;
import com.niit.firstdemo.model.Course;
import com.niit.firstdemo.service.CourseService;

@RunWith(SpringRunner.class)
@SpringJUnitConfig(classes=DBConfig.class)
public class CourseTestCase {

	@Autowired
	private CourseService courseService;
	
	@Test
	
	public void addCourseTest() {
		Course course=new Course();
		course.setCourse_description("c++ course");
		course.setCourse_name("DBS c++");
		course.setDuration("30 days");
		assertTrue("course added", courseService.addCourse(course));
	}
	
	@Test
	@Ignore
	public void updateCourseTest()
	{
		Course course=new Course();
		course.setCourse_id(1);
		course.setCourse_description("fullstack java course");
		course.setCourse_name("PGP FS");
		course.setDuration("100 days");
		assertTrue("course updated", courseService.updateCourse(course));
	}
	@Test
	@Ignore
	public void deleteCourseTest()
	{
		Course course=new Course();
		course.setCourse_id(1);
		assertTrue("deleted",courseService.deleteCourse(course));
	}
	
	@Test
	@Ignore
	public void getAllCoursesTest()
	{
	List<Course> courselist=courseService.getAllCourses();
	for(Course course:courselist)
		System.out.println(course);
	}
}
