package com.niit.firstdemo.dao;

import java.util.List;


import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.niit.firstdemo.model.Course;

@Repository
public class CouseDaoImpl implements CourdeDao
{
	@Autowired
	SessionFactory sessionFactory;

	public boolean addCourse(Course course) {
		sessionFactory.getCurrentSession().save(course);
		return true;
	}

	public boolean updateCourse(Course course) {
		sessionFactory.getCurrentSession().update(course);
		return false;
	}

	public boolean deleteCourse(Course course) {
		sessionFactory.getCurrentSession().delete(course);
		return false;
	}

	public List<Course> getAllCourses() {
		List<Course> courselist=sessionFactory.getCurrentSession().createQuery("from Course").list();
		
		return courselist;
	}

	@Override
	public Course searchCourseById(int courseId) {
		
		return sessionFactory.getCurrentSession().get(Course.class, courseId);
	}

}
