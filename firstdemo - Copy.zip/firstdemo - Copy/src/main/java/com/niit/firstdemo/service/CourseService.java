package com.niit.firstdemo.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.niit.firstdemo.dao.CourdeDao;
import com.niit.firstdemo.model.Course;
@Service
@Transactional
public class CourseService {
	@Autowired
	private CourdeDao courseDao;
	
	public boolean addCourse(Course course)
	{
		return courseDao.addCourse(course);
		
	}
	
	public boolean updateCourse(Course course)
	{
		return courseDao.updateCourse(course);
	}
	public boolean deleteCourse(Course course)
	{
		return courseDao.deleteCourse(course);
	}
	public List<Course> getAllCourses()
	{
		return courseDao.getAllCourses();
	}
	public Course searchCourseById(int courseId)
	{
		return courseDao.searchCourseById(courseId);
	}

}