package com.niit.firstdemo.dao;

import java.util.List;

import com.niit.firstdemo.model.Course;

public interface CourdeDao
{
	boolean addCourse(Course course);
	boolean updateCourse(Course course);
	boolean deleteCourse(Course course);
	List<Course> getAllCourses();
	Course searchCourseById(int courseId);
}
